/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hopital;

import java.util.Scanner;
import modele.Medecin;
import modele.Patient;
import service.PersonneServiceImpl;

/**
 *
 * @author MAME DIARRA
 */
public class Hopital {

    public static void main(String[] args) {
         PersonneServiceImpl act = new PersonneServiceImpl();
        System.out.println("Hello World!");
    Scanner sc = new Scanner(System.in);
            int choix;
            do {

                System.out.println("1 => Creer patient");
                System.out.println("2 => Creer medecin");
                System.out.println("3 => Planifier RV");
                System.out.println("4 =>Afficher les RV du jour");
                System.out.println("5 => Afficher les RV d'un medecin par jour");
                System.out.println("6 => Annuler RV");
                System.out.println("7 => Quitter");
                
                choix = sc.nextInt();
                sc.nextLine();
                switch (choix) {
                    case 1 -> 
                    {
                        
                        System.out.println("Entrez les informations Id Nom Prenom Adresse telephone Group Sanguin sexe et Antecedant");
                        int idp =sc.nextInt();
                        String nom =sc.next(); String prenom =sc.next();
                        String adresse =sc.next();String telephone =sc.next();
                        String grps =sc.next(); String sexe =sc.next(); String antecedant =sc.next();
                        Patient p= new Patient( grps, sexe, antecedant, idp,nom, prenom, adresse, telephone);
                          act.ajouterPatient(p);
                    }
                    case 2 -> {
                        System.out.println("Entrez les informations Id Nom Prenom Adresse telephone matricule et specialite");
                        int idm =sc.nextInt();
                        String nom =sc.next(); String prenom =sc.next();
                        String adresse =sc.next();String telephone =sc.next();
                        String matricule =sc.next(); String specialite =sc.next();
                        Medecin m= new Medecin(matricule,specialite,idm,nom,prenom,adresse,telephone); 
                                   act.ajouterMedecin(m);

                    }  
                    



                       
                        
                    

                 }
               
                }while (choix!=7); 
         
            
    }
}
    
                