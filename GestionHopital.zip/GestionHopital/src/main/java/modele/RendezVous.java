/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

/**
 *
 * @author MAME DIARRA
 */
public class RendezVous {
    int numero;
    String date,heured,heuref,etat;
    Patient p;
    Medecin m;

    public RendezVous(int numero, String date, String heured, String heuref, Patient p, Medecin m) {
        this.numero = numero;
        this.date = date;
        this.heured = heured;
        this.heuref = heuref;
        this.p = p;
        this.m = m;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getHeured() {
        return heured;
    }

    public void setHeured(String heured) {
        this.heured = heured;
    }

    public String getHeuref() {
        return heuref;
    }

    public void setHeuref(String heuref) {
        this.heuref = heuref;
    }

    public Patient getP() {
        return p;
    }

    public void setP(Patient p) {
        this.p = p;
    }

    public Medecin getM() {
        return m;
    }

    public void setM(Medecin m) {
        this.m = m;
    }

   
   

   
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

  
   
    
}
