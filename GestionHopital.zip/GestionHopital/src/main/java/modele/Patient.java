/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

/**
 *
 * @author MAME DIARRA
 */
public class Patient extends Personne {
     String groupesqnguin, sexe,antecedants;

    public Patient(String groupesqnguin, String sexe, String antecedants, int id, String nom, String prenom, String adresse, String telephone) {
        super(id, nom, prenom, adresse, telephone);
        this.groupesqnguin = groupesqnguin;
        this.sexe = sexe;
        this.antecedants = antecedants;
    }
    public Patient(int id, String nom, String prenom, String adresse, String telephone) {
        super(id, nom, prenom, adresse, telephone);
    }

    public String getGroupesqnguin() {
        return groupesqnguin;
    }

    public void setGroupesqnguin(String groupesqnguin) {
        this.groupesqnguin = groupesqnguin;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public String getAntecedants() {
        return antecedants;
    }

    public void setAntecedants(String antecedants) {
        this.antecedants = antecedants;
    }
    
}
