/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modele;

/**
 *
 * @author MAME DIARRA
 */
public class Medecin extends Personne {
    String matricule,specialite;
    
    public Medecin(int id, String nom, String prenom, String adresse, String telephone) {
        super(id, nom, prenom, adresse, telephone);
        
    }

    public Medecin(String matricule, String specialite, int id, String nom, String prenom, String adresse, String telephone) {
        super(id, nom, prenom, adresse, telephone);
        this.matricule = matricule;
        this.specialite = specialite;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getSpecialite() {
        return specialite;
    }

    public void setSpecialite(String specialite) {
        this.specialite = specialite;
    }
    
}
