/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package service;

import modele.RendezVous;

/**
 *
 * @author MAME DIARRA
 */
public interface RvService {
    public int addRV(RendezVous r);
    public int annulerRV(RendezVous r);
}
