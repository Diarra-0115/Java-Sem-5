/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import modele.RendezVous;

/**
 *
 * @author MAME DIARRA
 */
public  class RvServiceImpl implements RvService {

  

    
    @Override
    public int addRV(RendezVous r) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int annulerRV(RendezVous r) {
        throw new UnsupportedOperationException("Not supported yet.");
        
    }
    
}
