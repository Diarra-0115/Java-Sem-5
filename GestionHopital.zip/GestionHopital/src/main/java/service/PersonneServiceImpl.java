/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import modele.Medecin;
import modele.Patient;

/**
 *
 * @author MAME DIARRA
 */
import java.sql.*;

public class PersonneServiceImpl implements PersonneService {


    @Override
    public int ajouterPatient(Patient P) {
        
    try
    {
      //étape 1: charger la classe driver
      Class.forName("com.mysql.jdbc.Driver");
            //étape 3: créer l'objet statement
            try ( //étape 2: créer l'objet de connexion
                    Connection conn = (Connection) DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/gestionatelier", "root", "")) {
                //étape 3: créer l'objet statement
                Statement stmt = conn.createStatement();
                //étape 4: exécuter la requête
                System.out.println("Insertion...");
                String sql = "INSERT INTO Patient VALUES ("+P.getId()+","+P.getNom()+","+P.getPrenom()+","+P.getAdresse()+","+P.getTelephone()+","+P.getGroupesqnguin()+","+P.getSexe()+","+P.getAntecedants()+")";
                stmt.executeUpdate(sql);
               
                System.out.println("Données insérés dans la table...");
                //étape 5: fermez l'objet de connexion
            }
    }
    catch(ClassNotFoundException | SQLException e){ 
      System.out.println(e);
    
       }
        return 0;
    }

   
    @Override
    public int ajouterMedecin(Medecin m) {
        try
    {
      //étape 1: charger la classe driver
      Class.forName("com.mysql.jdbc.Driver");
            //étape 3: créer l'objet statement
            try ( //étape 2: créer l'objet de connexion
                    Connection conn = (Connection) DriverManager.getConnection(
                            "jdbc:mysql://localhost:3306/gestionatelier", "root", "")) {
                //étape 3: créer l'objet statement
                Statement stmt = conn.createStatement();
                //étape 4: exécuter la requête
                System.out.println("Insertion...");
               String sql = "INSERT INTO Medecin VALUES ("+m.getId()+","+m.getNom()+","+m.getPrenom()+","+m.getAdresse()+","+m.getTelephone()+","+m.getMatricule()+","+m.getSpecialite()+")";
                stmt.executeUpdate(sql);
               
                System.out.println("Données insérés dans la table...");
                //étape 5: fermez l'objet de connexion
            }
    }
    catch(ClassNotFoundException | SQLException e){ 
      System.out.println(e);
    
       }
        return 0;
    }
    
}
